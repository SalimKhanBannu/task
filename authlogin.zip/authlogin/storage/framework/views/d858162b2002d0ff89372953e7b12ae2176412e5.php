<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="DashboardKit is made using Bootstrap 5 design framework. Download the free admin template & use it for your project.">
    <meta name="keywords" content="DashboardKit, Dashboard Kit, Dashboard UI Kit, Bootstrap 5, Admin Template, Admin Dashboard, CRM, CMS, Free Bootstrap Admin Template">
    <meta name="author" content="DashboardKit ">


    <!-- Favicon icon -->
    <!-- <link rel="icon" href="assets/images/favicon.svg" type="image/x-icon"> -->
    <link rel="icon" href="<?php echo e(asset('public/assets/images/favicon.svg')); ?>" type="image/x-icon">

    <!-- font css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/fonts/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/fonts/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/fonts/material.css')); ?>">
    <!-- vendor css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>" id="main-style-link">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/dataTableBootstrap.css')); ?>">
<style>
  .link{
    color:blue !important;
    text-decoration:underline;
    float:right;
  }
</style>
</head>
<body>
<!-- [ auth-signin ] start -->
<div class="auth-wrapper">
	<div class="auth-content">
		<div class="card">
			<div class="row align-items-center text-center">
				<div class="col-md-12">
					<div class="card-body">
					<form action="<?php echo e(url('vendor/vendorLogin')); ?>" method="post"  class="needs-validation" novalidate autocomplete="off">
						<?php echo csrf_field(); ?>
						 
						<h4 class="mb-5 f-w-700">Vendor Signin</h4>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
    	<a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close"><i class="fas fa-times-circle text-danger"></i></a>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>	

<?php if(session('msg')): ?>
<div class="alert alert-danger alert-dismissible">
<a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close"><i class="fas fa-times-circle text-danger"></i></a>
<?php echo e(session('msg')); ?>

</div>      
<?php endif; ?>


<div class="input-group mb-3">
    <div class="input-group has-validation">
      <span class="input-group-text"><i data-feather="mail"></i></span>
      <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
</div>
</div>

<div class="input-group mb-3">
    <div class="input-group has-validation">
      <span class="input-group-text"><i data-feather="lock"></i></span>
    <input type="password" name="password" class="form-control" placeholder="Password" value="<?php echo e(old('password')); ?>">
</div>
</div>
						 
	<button class="btn btn-block btn-success mb-4" style="width:100%;">Signin</button>

    <a href="<?php echo e(url('vendor/signup')); ?>" class="link">Dont have any account?</a>
						 
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- [ auth-signin ] end -->


 <script src="<?php echo e(asset('public/assets/js/vendor-all.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/assets/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/plugins/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/pcoded.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/plugins/apexcharts.min.js')); ?>"></script>
 
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-sale.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-sale.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/dataTable.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/dataTableBootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/mychart.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\authlogin\resources\views/vendor/login.blade.php ENDPATH**/ ?>