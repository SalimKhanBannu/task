<!DOCTYPE html>
<html>
<head>
	<title>Welcom Vendor</title>
</head>
<body>
<br><br><br>
<center>
	<h1> Role: <?php echo e(session('role')); ?> </h1>
	<h1> Welcome <?php echo e(session('name')); ?> </h1>
	<a href="<?php echo e(url('logout')); ?>">Logout</a>
</center>


</body>
</html><?php /**PATH C:\xampp\htdocs\authlogin\resources\views/vendor/welcome_vendor.blade.php ENDPATH**/ ?>