<!DOCTYPE html>
<html lang="en">

<head>
    <title>News</title>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="DashboardKit is made using Bootstrap 5 design framework. Download the free admin template & use it for your project.">
    <meta name="keywords" content="DashboardKit, Dashboard Kit, Dashboard UI Kit, Bootstrap 5, Admin Template, Admin Dashboard, CRM, CMS, Free Bootstrap Admin Template">
    <meta name="author" content="DashboardKit ">


    <!-- Favicon icon -->
    <!-- <link rel="icon" href="assets/images/favicon.svg" type="image/x-icon"> -->
    <link rel="icon" href="{{asset('public/assets/images/favicon.svg')}}" type="image/x-icon">

    <!-- font css -->
    <link rel="stylesheet" href="{{asset('public/assets/fonts/feather.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets/fonts/fontawesome.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets/fonts/material.css')}}">
    <!-- vendor css -->
    <link rel="stylesheet" href="{{asset('public/assets/css/style.css')}}" id="main-style-link">
    <link rel="stylesheet" href="{{asset('public/assets/css/dataTableBootstrap.css')}}">

</head>

<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ Mobile header ] start -->
	<div class="pc-mob-header pc-header">
		<div class="m-header">
				<a href="index.html" class="b-brand">
					<!-- ========   change your logo hear   ============ -->
					<img src="assets/images/logo.svg" alt="" class="logo logo-lg">
					<img src="assets/images/logo-sm.svg" alt="" class="logo logo-sm">
				</a>
			</div>
		<div class="pcm-toolbar">
			<a href="#!" class="pc-head-link" id="mobile-collapse">
				<div class="hamburger hamburger--arrowturn">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>
			</a>
			<a href="#!" class="pc-head-link" id="headerdrp-collapse">
				<i data-feather="align-right"></i>
			</a>
			<a href="#!" class="pc-head-link" id="header-collapse">
				<i data-feather="more-vertical"></i>
			</a>
		</div>
	</div>
	<!-- [ Mobile header ] End -->

	<!-- [ navigation menu ] start -->
	<nav class="pc-sidebar" style="background:black;">
		<div class="navbar-wrapper">
			<div class="m-header">
				<a href="{{url('/dashboard')}}" class="b-brand">
					<!-- ========   change your logo hear   ============ -->
		<img src="{{asset('public/images/logo_img/logo-inner.png')}}" alt="" class="logo logo-lg" width="170" height="60">
		<img src="{{asset('public/images/logo_img/logo-inner.png')}}" alt="" class="logo logo-sm" width="170" height="60">
				</a>
			</div>
			<div class="navbar-content">
				<ul class="pc-navbar">
					 
					<li class="pc-item">
						<a href="{{url('/admin/dashboard')}}" class="pc-link "><span class="pc-micon"><i class="material-icons-two-tone">home</i></span><span class="pc-mtext">Dashboard</span></a>
					</li>
 
					 
<li class="pc-item pc-hasmenu">
	<a href="javascript:void(0)" class="pc-link "><span class="pc-micon"><i class="material-icons-two-tone">business_center</i></span><span class="pc-mtext">News</span><span class="pc-arrow"><i data-feather="chevron-right"></i></span></a>
  <ul class="pc-submenu">
  	<li class="pc-item"><a class="pc-link" href="{{url('admin/add_categories')}}">Add Categories</a></li>
		  <li class="pc-item"><a class="pc-link" href="{{url('admin/view_categories')}}">View Categories</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/add_news')}}">Add News</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/view_news')}}">View News</a> 
  </ul>
</li>

<li class="pc-item pc-hasmenu">
	<a href="javascript:void(0)" class="pc-link "><span class="pc-micon"><i class="material-icons-two-tone">business_center</i></span><span class="pc-mtext">Projects</span><span class="pc-arrow"><i data-feather="chevron-right"></i></span></a>
	<ul class="pc-submenu">
	  <li class="pc-item"><a class="pc-link" href="{{url('admin/add_projects')}}">Add Projects</a></li>
	  <li class="pc-item"><a class="pc-link" href="{{url('admin/view_projects')}}">View Projects</a></li>
	</ul>
</li>

<li class="pc-item pc-hasmenu">
	<a href="javascript:void(0)" class="pc-link "><span class="pc-micon"><i class="material-icons-two-tone">business_center</i></span><span class="pc-mtext">Gallery</span><span class="pc-arrow"><i data-feather="chevron-right"></i></span></a>
  <ul class="pc-submenu">
  	<li class="pc-item">
  	<a class="pc-link" href="{{url('admin/add_gallery_categories')}}">Add Categories</a></li>
    <li class="pc-item">
	<a class="pc-link" href="{{url('admin/view_gallery_categories')}}">View Categories</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/add_gallery_posts')}}">Add Images</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/view_gallery_posts')}}">View Images</a> 
  </ul>
</li>

<li class="pc-item pc-hasmenu">
<a href="#!" class="pc-link "><span class="pc-micon"><i class="material-icons-two-tone">business_center</i></span><span class="pc-mtext">Blog</span><span class="pc-arrow"><i data-feather="chevron-right"></i></span></a>
<ul class="pc-submenu">
  	<li class="pc-item">
  	<a class="pc-link" href="{{url('admin/add_blog_categories')}}">Add Categories</a></li>
    <li class="pc-item">
	<a class="pc-link" href="{{url('admin/view_blog_categories')}}">View Categories</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/add_blog_posts')}}">Add Posts</a></li>
    <li class="pc-item"><a class="pc-link" href="{{url('admin/view_blog_posts')}}">View Posts</a> 
  </ul>
</li>
 
 
			 

				</ul>
			</div>
		</div>
	</nav>
	<!-- [ navigation menu ] end -->
	<!-- [ Header ] start -->
	<header class="pc-header">
		<div class="header-wrapper">
			<div class="mr-auto pc-mob-drp">
				<ul class="list-unstyled">
					<li class="dropdown pc-h-item">
						 
						<div class="dropdown-menu pc-h-dropdown">
							<a href="#!" class="dropdown-item">
								<i class="material-icons-two-tone">account_circle</i>
								<span>My Account</span>
							</a>
							<div class="pc-level-menu">
								<a href="#!" class="dropdown-item">
									<i class="material-icons-two-tone">list_alt</i>
									<span class="float-right"><i data-feather="chevron-right" class="mr-0"></i></span>
									<span>Level2.1</span>
								</a>
								<div class="dropdown-menu pc-h-dropdown">
									<a href="#!" class="dropdown-item">
										<i class="fas fa-circle"></i>
										<span>My Account</span>
									</a>
									<a href="#!" class="dropdown-item">
										<i class="fas fa-circle"></i>
										<span>Settings</span>
									</a>
									<a href="#!" class="dropdown-item">
										<i class="fas fa-circle"></i>
										<span>Support</span>
									</a>
									<a href="#!" class="dropdown-item">
										<i class="fas fa-circle"></i>
										<span>Lock Screen</span>
									</a>
									<a href="#!" class="dropdown-item">
										<i class="fas fa-circle"></i>
										<span>Logout</span>
									</a>
								</div>
							</div>
							<a href="#!" class="dropdown-item">
								<i class="material-icons-two-tone">settings</i>
								<span>Settings</span>
							</a>
							<a href="#!" class="dropdown-item">
								<i class="material-icons-two-tone">support</i>
								<span>Support</span>
							</a>
							<a href="#!" class="dropdown-item">
								<i class="material-icons-two-tone">https</i>
								<span>Lock Screen</span>
							</a>
							<a href="#!" class="dropdown-item">
								<i class="material-icons-two-tone">chrome_reader_mode</i>
								<span>Logout</span>
							</a>
						</div>
					</li>
				</ul>
			</div>
			<div class="ml-auto">
				<ul class="list-unstyled">
					<li class="dropdown pc-h-item">
						<a class="pc-head-link dropdown-toggle arrow-none mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
							<i class="material-icons-two-tone">search</i>
						</a>
						<div class="dropdown-menu dropdown-menu-right pc-h-dropdown drp-search">
							<form class="px-3">
								<div class="form-group mb-0 d-flex align-items-center">
									<i data-feather="search"></i>
									<input type="search" class="form-control border-0 shadow-none" placeholder="Search here. . .">
								</div>
							</form>
						</div>
					</li>
					<li class="dropdown pc-h-item">
					<a class="pc-head-link dropdown-toggle arrow-none mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
<img src="{{asset('public/images/site_img/admin.jpg')}}" alt="user-image" class="user-avtar">
							<span>
								<span class="user-name">
								{{ session('name') }}
							    </span>
								<!-- <span class="user-desc">Administrator</span> -->
							</span>
						</a>
						<div class="dropdown-menu dropdown-menu-right pc-h-dropdown">			
							<a href="{{url('admin/logout')}}" class="dropdown-item">
								<i class="material-icons-two-tone">chrome_reader_mode</i>
								<span>Logout</span>
							</a>
						</div>
					</li>
				</ul>
			</div>

		</div>
	</header>
	<!-- [ Header ] end -->

@yield('content')


 <script src="{{asset('public/assets/js/vendor-all.min.js')}}"></script>
 <script src="{{asset('public/assets/js/plugins/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/assets/js/plugins/feather.min.js')}}"></script>
    <script src="{{asset('public/assets/js/pcoded.min.js')}}"></script>

<!-- Apex Chart -->
<script src="{{asset('public/assets/js/plugins/apexcharts.min.js')}}"></script>
 
<!-- custom-chart js -->
<script src="{{asset('public/assets/js/pages/dashboard-sale.js')}}"></script>
<script src="{{asset('public/assets/js/pages/dashboard-sale.js')}}"></script>
<script src="{{asset('public/assets/js/dataTable.js')}}"></script>
<script src="{{asset('public/assets/js/dataTableBootstrap.js')}}"></script>
<script src="{{asset('public/assets/js/mychart.js')}}"></script>
<script src="{{asset('public/assets/ckeditor/ckeditor.js')}}"></script>
<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );

$('.close').click(function(){
   $('.alert').hide();
});

</script>
 

</body>

</html>
