<!DOCTYPE html>
<html>
<head>
	<title>Welcom Admin</title>
</head>
<body>
<br><br><br>
<center>
	<h1> Role: {{ session('role') }} </h1>
	<h1> Welcome {{ session('name') }} </h1>
	<a href="{{url('logout')}}">Logout</a>
</center>


</body>
</html>