<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
use App\Models\Vendor;

class LoginController extends Controller
{
    // ------ For Admin -----------------------------
    public function login(Request $request)
    {
    		$request->validate([
    			'email' 	=> 	'required',
    			'password'	=> 	'required'
    		]);

        $admin = Admin::where('email', '=', $request->email)->first();

        if (!$admin) 
        {
          return redirect('/admin/login')->with('msg', 'Wrong username or password.');
        }
        else
        {
        	if(Hash::check($request->password, $admin->password) && $admin->role == 'admin') 
		    {
              session([
                   'name'		=>		$admin->name, 
                   'role'		=>		$admin->role, 
	       	   ]);

             return redirect('/welcome_admin');
		    } 
		    else 
		    {
		      return redirect('/admin/login')->with('msg', 'Wrong username or password.');
		    }
        }
    }
    // ------- End for Admin ----------------------

    // --------For Vendor -------------------------
     public function vendorSignup(Request $request)
     {
       $request->validate([
         'name'     => 'required',
         'email'    => 'required|email',
         'password' => 'required'
       ]);

       $vendor = Vendor::create([
         'name'     => $request->name,
         'email'    => $request->email,
         'password' => Hash::make($request->password),
         'role'    => 'vendor'
       ]);

       if($vendor)
        {  
            return redirect('vendor/login')->with('msg', 'Account created successfully.');
        }
        else
        {
          return redirect('vendor/signup')->with('msg', 'Something went wrong! Please try again');
        }

     }

     public function vendorLogin(Request $request)
    {
        $request->validate([
          'email'     =>  'required|email',
          'password'  =>  'required'
        ]);
 
        $vendor = Vendor::where('email', '=', $request->email)->first();

        if (!$vendor) 
        {
          return redirect('/vendor/login')->with('msg', 'Wrong username or password.');
        }
        else
        {
           if(Hash::check($request->password, $vendor->password) && $vendor->role == 'vendor') 
            {
                  session([
                       'name'   =>    $vendor->name, 
                       'role'   =>    $vendor->role, 
                 ]);

                 return redirect('/welcome_vendor');
            } 
            else 
            {
              return redirect('/vendor/login')->with('msg', 'Wrong username or password.');
            }
        }
    }
    //---------End for Vendor ---------------------

    public function logout()
  	{
  		session()->flush(); //   delete all sessions
  		return redirect('/');
  	}

}
